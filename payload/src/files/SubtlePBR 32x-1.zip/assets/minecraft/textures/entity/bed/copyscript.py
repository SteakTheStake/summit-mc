from PIL import Image

colors = [
    "black", 
    "blue",
    "brown",
    "cyan",
    "gray",
    "green",
    "light_blue",
    "light_gray",
    "lime",
    "magenta",
    "orange",
    "pink",
    "purple",
    "red",
    "white",
    "yellow",
]
suffix = "_s" # Specify the suffix here, i.e: "_s", "_n", "_terracotta_n", etc...
image = Image.open("_s.png") # Place the script in the same folder as the image, and open it using it's filename.format

for color in colors:
    image.save(f"{color}{suffix}.png")
