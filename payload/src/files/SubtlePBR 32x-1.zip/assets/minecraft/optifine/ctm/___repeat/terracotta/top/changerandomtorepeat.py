import yaml

colors = {
    "black": "#25170f",
    "blue": "#9172d8",
    "brown": "#613f2c",
    "cyan": "#3d4645",
    "gray": "#3a2a24",
    "green": "#0d4700",
    "light_blue": "#716d8a",
    "light_gray": "#977b72",
    "lime": "#5b7400",
    "magenta": "#621a2f",
    "orange": "#b34300",
    "pink": "#f496b0",
    "purple": "#764656",
    "red": "#8d3e2e",
    "white": "#d4b29f",
    "yellow": "#bd9312",
    "": "#a35c41",
}

for color in colors:
    if color == "":
        with open(f"terracotta/mat.yml", "r") as f:
            data = yaml.safe_load(f)

        data['ctm']['method'] = 'of-repeat'

        with open(f"terracotta/mat.yml", "w") as f:
            yaml.dump(data, f)
    else:
        with open(f"{color}_terracotta/mat.yml", "r") as f:
            data = yaml.safe_load(f)

        data['ctm']['method'] = 'of-repeat'

        with open(f"{color}_terracotta/mat.yml", "w") as f:
            yaml.dump(data, f)

# for color in colors:
#     os.remove(f"{color}_terracotta")