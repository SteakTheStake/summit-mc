import os
from PIL import Image, ImageChops, ImageEnhance
import time

colors = [
    {"color": "black", "hex": "#0f0f0f"},
    {"color": "blue", "hex": "#2b1487"},
    {"color": "brown", "hex": "#40160a"},
    {"color": "cyan", "hex": "#00b59d"},
    {"color": "gray", "hex": "#2b2b2b"},
    {"color": "green", "hex": "#0e5e00"},
    {"color": "light_blue", "hex": "#57b6ff"},
    {"color": "light_gray", "hex": "#808080"},
    {"color": "lime", "hex": "#54fc00"},
    {"color": "magenta", "hex": "#d10092"},
    {"color": "orange", "hex": "#f57200"},
    {"color": "pink", "hex": "#ff73ce"},
    {"color": "purple", "hex": "#8b00c2"},
    {"color": "red", "hex": "#a10000"},
    {"color": "yellow", "hex": "#fca000"},
]

base_folder = "shulker_white"

for color_info in colors:
    color = color_info["color"]
    hex_code = color_info["hex"]

    # Create a new folder for each color
    new_folder_name = f"shulker_{color}"
    new_folder_path = os.path.join(os.getcwd(), new_folder_name)
    os.makedirs(new_folder_path, exist_ok=True)

    # Copy all files from the "base" folder to the new color folder
    for root, dirs, files in os.walk(base_folder):
        for file in files:
            source_file = os.path.join(root, file)
            dest_file = os.path.join(new_folder_path, file)
            with open(source_file, "rb") as src, open(dest_file, "wb") as dest:
                dest.write(src.read())

    # Open and process the "color.png" image
    image_path = os.path.join(new_folder_path, "color.png")
    image = Image.open(image_path)

    # Convert hex code to RGB values
    r = int(hex_code[1:3], 16)
    g = int(hex_code[3:5], 16)
    b = int(hex_code[5:7], 16)

    # Create a solid color image with the RGB values
    color_image = Image.new("RGBA", image.size, (r, g, b, 255))

    # Multiply the color image with the "color.png" image
    result_image = ImageChops.multiply(image, color_image)
    # result_image = Image.composite(color_image, image, color_image)

    # Save the result image back to the folder
    result_image.save(image_path)

print("Processing completed.")
