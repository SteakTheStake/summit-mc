from PIL import Image
import numpy as np
import shutil

colors = {
    "black": "#25170f",
    "blue": "#9172d8",
    "brown": "#613f2c",
    "cyan": "#3d4645",
    "gray": "#3a2a24",
    "green": "#0d4700",
    "light_blue": "#716d8a",
    "light_gray": "#977b72",
    "lime": "#5b7400",
    "magenta": "#621a2f",
    "orange": "#b34300",
    "pink": "#f496b0",
    "purple": "#764656",
    "red": "#8d3e2e",
    "white": "#d4b29f",
    "yellow": "#bd9312",
    "": "#a35c41",
}

# colors = {
# 'black': '#252628',
# 'blue': '#2d2f8f',
# 'brown': '#603c20',
# 'cyan': '#157788',
# 'gray': '#65676a',
# 'green': '#5ba65b',
# 'light_blue': '#2489c7',
# 'light_gray': '#afafa9',
# 'lime': '#5ea918',
# 'magenta': '#a9319f',
# 'orange': '#e16101',
# 'pink': '#d5658f',
# 'purple': '#9354c6',
# 'red': '#d64545',
# 'white': '#f0f2f2',
# 'yellow': '#f1af15',
# }

name = "terracotta"
img = "Substance_graph_basecolor.png"

# Copying the folders
# folder_path = "top/terracotta"
# for color in colors:
#     new_name = f"top/{color}_{name}"
#     shutil.copytree(folder_path, new_name)

#     print(f"Folder '{folder_path}' copied to '{new_name}'")

# Testing image
# im = Image.open("concretes/black_concrete/Substance_graph_basecolor.png").convert("RGB")
# im.show()

# Applying the colors
for color in colors:
    hexC = colors[color]
    rgb_value = tuple(int(hexC[i:i+2], 16) for i in (1, 3, 5))
    rgb_normalized = tuple(map(lambda x: x/255, rgb_value))
    print("RGB value:", rgb_value)
    print("Normalized RGB value:", rgb_normalized)
    

    image = Image.open("./Substance_graph_basecolor.png").convert('RGB')
    arr = np.array(image)
    for a in arr:
        for i in a:
            i[0] *= rgb_normalized[0]
            i[1] *= rgb_normalized[1]
            i[2] *= rgb_normalized[2]

    im = Image.fromarray(arr)
    im.save(f"top/{color}_{name}/color.png")

# Replacing mat.yml file
# src_file = f"{name}s/Substance_graph_basecolor.png"

# for color in colors:
#     dest_file = f"{name}s/{color}_{name}/Substance_graph_basecolor.png"
#     shutil.copy2(src_file, dest_file)
